from flask import Flask, flash, redirect, render_template, request, session
import psycopg2

app = Flask(__name__)

app.secret_key = 'your_secret_key'
def get_db_connection():
    conn = psycopg2.connect(
        dbname='doanck',       # Tên cơ sở dữ liệu
        user='postgres',       # Tên người dùng
        password='123456',     # Mật khẩu
        host='localhost',      # Địa chỉ máy chủ
        port='5432'            # Cổng
    )
    return conn
@app.route('/check_connection')
def check_connection():
    try:
        conn = get_db_connection()
        conn.close()  # Đóng kết nối ngay lập tức
        return "Kết nối đến cơ sở dữ liệu thành công!", 200
    except Exception as e:
        return f"Lỗi kết nối đến cơ sở dữ liệu: {e}", 500
@app.route('/')
def index0():
    return render_template('index0.html', logged_in='username' in session)
@app.route('/index')
def index():
    return render_template('index.html', logged_in='username' in session)

# @app.route('/login')
# def login():
#     return render_template('login.html')
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Kết nối đến database
        conn = get_db_connection()
        cur = conn.cursor()

        # Kiểm tra thông tin tài khoản
        cur.execute("SELECT * FROM users WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()  # Lấy một bản ghi

        # Đóng kết nối
        cur.close()
        conn.close()

        if user:
            # Đăng nhập thành công
            session['username'] = username  # Lưu thông tin đăng nhập vào session
            flash('Đăng nhập thành công!', 'success')
            return redirect('/index')  # Chuyển hướng về trang chính
        else:
            # Đăng nhập thất bại
            flash('Tên đăng nhập hoặc mật khẩu không đúng!', 'error')

    return render_template('login.html')
# @app.route('/account')
# def account():
#     return render_template('create-an-account.html')
@app.route('/account', methods=['GET', 'POST'])
def account():
    if request.method == 'POST':
        # Lấy dữ liệu từ request
        username = request.form['username']
        password = request.form['password']

        # Kết nối đến database
        conn = get_db_connection()
        cur = conn.cursor()

        # Thêm dữ liệu vào bảng users
        sql = """
        INSERT INTO users (username, password) 
        VALUES (%s, %s)
        """
        cur.execute(sql, (username, password))
        conn.commit()

        # Đóng kết nối
        cur.close()
        conn.close()

        # Hiển thị thông báo thành công
        flash('Tạo tài khoản thành công!', 'success')
        return redirect('/index')

    return render_template('create-an-account.html')
@app.route('/logout')
def logout():
    # Xóa thông tin người dùng khỏi session
    session.pop('username', None)  # Xóa username khỏi session
    flash('Bạn đã đăng xuất thành công!', 'success')  # Thông báo đăng xuất thành công
    return redirect('/')  # Chuyển hướng về trang chính
# @app.route('/create')
# def create():
#     return render_template('create.html')
@app.route('/create', methods=['GET', 'POST'])
def create():
    if request.method == 'POST':
        # Lấy dữ liệu từ request
        invoice_id = request.form['ID']
        customer_name = request.form['customerName']
        phone_number = request.form['phonenumber']
        product_name = request.form['productName']
        quantity = request.form['quantity']
        total = request.form['total'].replace('.', '')  # Xóa dấu phẩy và dấu chấm

        # Kết nối đến database
        conn = get_db_connection()
        cur = conn.cursor()

        # Thêm dữ liệu vào bảng orders
        sql = """
        INSERT INTO orders (invoice_id, customer_name, phone_number, product_name, quantity, total) 
        VALUES (%s, %s, %s, %s, %s, %s)
        """
        cur.execute(sql, (invoice_id, customer_name, phone_number, product_name, quantity, total))
        conn.commit()

        # Đóng kết nối
        cur.close()
        conn.close()

        # Hiển thị thông báo thành công
        flash('Đơn hàng đã được tạo thành công!', 'success')
        return redirect('/create')

    return render_template('create.html')


@app.route('/quanly', methods=['GET'])
def quanly():
    # Kết nối đến database
    conn = get_db_connection()
    cur = conn.cursor()

    # Lấy dữ liệu từ bảng orders
    cur.execute("SELECT * FROM orders")
    orders = cur.fetchall()
    print(orders)  # In ra danh sách đơn hàng để kiểm tra
    # Đóng kết nối
    cur.close()
    conn.close()

    # Gửi dữ liệu đến template
    return render_template('quanlydonhang.html', orders=orders)

@app.route('/search', methods=['GET', 'POST'])
def search():
    order = None  # Khởi tạo biến để lưu thông tin đơn hàng
    if request.method == 'POST':
        invoice_id = request.form['invoice_id']  # Lấy mã hóa đơn từ form

        # Kết nối đến database
        conn = get_db_connection()
        cur = conn.cursor()

        # Truy vấn để tìm đơn hàng theo mã hóa đơn
        cur.execute("SELECT * FROM orders WHERE invoice_id = %s", (invoice_id,))
        order = cur.fetchone()  # Lấy một bản ghi

        # Đóng kết nối
        cur.close()
        conn.close()

    return render_template('search.html', order=order)


if __name__ == '__main__':
    app.run(debug=True)  # Bật chế độ debug để dễ dàng phát hiện lỗi